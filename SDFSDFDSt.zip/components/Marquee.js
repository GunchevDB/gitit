class Marquee {
  constructor(attributes = {}) {
    this.$element = attributes.element;
  }
}

export default Marquee;
